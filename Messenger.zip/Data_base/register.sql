-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 26.248.111.145:3306
-- Время создания: Май 31 2024 г., 02:24
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `register`
--

-- --------------------------------------------------------

--
-- Структура таблицы `message`
--

CREATE TABLE `message` (
  `id` int UNSIGNED NOT NULL,
  `message_id` int NOT NULL,
  `chat_id` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `user_id` int NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date_create` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `message`
--

INSERT INTO `message` (`id`, `message_id`, `chat_id`, `user_id`, `content`, `date_create`) VALUES
(1, 1, '1, 2', 1, 'Привет, как дела?', '2024-05-22 17:36:00'),
(2, 2, '1, 2', 1, 'аылвалывал', '2024-05-22 17:36:12'),
(3, 3, '1, 2', 1, 'Уууууу', '2024-05-24 20:02:17'),
(4, 4, '1, 2', 1, 'fsd', '2024-05-25 18:03:12'),
(5, 5, '1, 2', 2, 'Я Паша', '2024-05-27 15:37:32'),
(6, 6, '1, 2', 1, 'Привет, Паша!', '2024-05-28 01:37:51');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int UNSIGNED NOT NULL,
  `email` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pass` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `friends` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `zapros` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `zayavki` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `pass`, `name`, `friends`, `zapros`, `zayavki`) VALUES
(1, 'Yurik@yandex.ru', '1234', 'Юрий', ', 2, 3, 15, 17', '', ''),
(2, 'MatveevUra@gh.gh', '1234', 'Паша', ', 1, 15', '', ''),
(3, 'YuMa@yandex.ru', '1234', 'Михаил', ', 1', '', ''),
(4, 'NoNoNo@yandex.ru', '1234', 'Артём', '', '', ''),
(5, 'Matveevura228@gmail.com', '1234', 'Михаил', '', '', ''),
(6, 'Yurikas@gmail.com', '1234', 'Евгений', '', '', ''),
(7, 'DjYu@yandex.ru', '1234', 'Мария', '', '', ''),
(8, 'Fukas@yandex.ru', '1234', 'Ксения', '', '', ''),
(9, 'Mavridi@gmail.com', '1234', 'Муравей', '', '', ''),
(10, 'NeZnayu@yandex.ru', '1234', 'Александр', '', '', ''),
(11, 'NeYura@yandex.ru', '1234', 'Сергей', '', '', ''),
(12, 'Amazing@yandex.ru', '1234', 'Алексей', '', '', ''),
(13, 'UraMatveev228@yandex.ru', '1234', 'Максим', '', '', ''),
(14, 'Yura_2004@yandex.ru', '1234', 'Пример', '', '', ''),
(15, 'uramatveev@gmail.com', '1234', 'Кристина', ', 1, 2', '', ''),
(16, 'matveevura2@gmail.com', '1234', 'Уткин', '', '', ''),
(17, 'oisddfoj@gmail.com', '1234', 'Мурахат', ', 1', '', ''),
(18, 'Primer@gmail.com', 'Primer_pass', 'Primer', '', '', '');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `message`
--
ALTER TABLE `message`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
