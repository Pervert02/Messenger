<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

// Подключение к базе данных
$servername = "26.248.111.145";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Получение данных от клиента
$userEmail = $_POST['user_email']; // Email пользователя
$friendEmail = $_POST['friend_email']; // Email друга, которого удаляем из друзей
$userid = $_POST['userid']; // ID пользователя
echo $userEmail;
// Получение ID пользователя userEmail
$userQuery = $conn->query("SELECT id FROM users WHERE email = '$userEmail'");
if ($userQuery->num_rows > 0) {
  $userRow = $userQuery->fetch_assoc();
  $userId = $userRow['id'];
} else {
  echo json_encode(array("success" => false, "message" => "Пользователь с email $userEmail не найден"));
  exit();
}

// Получение ID пользователя friendEmail
$friendQuery = $conn->query("SELECT id FROM users WHERE email = '$friendEmail'");
if ($friendQuery->num_rows > 0) {
  $friendRow = $friendQuery->fetch_assoc();
  $friendId = $friendRow['id'];
} else {
  echo json_encode(array("success" => false, "message" => "Пользователь с email $friendEmail не найден"));
  exit();
}

// Удаление друга из списка друзей пользователя userEmail
$userFriendsQuery = $conn->query("SELECT friends FROM users WHERE id = '$userId'");
if ($userFriendsQuery->num_rows > 0) {
  $userFriendsRow = $userFriendsQuery->fetch_assoc();
  $userFriends = explode(', ', $userFriendsRow['friends']);
  
  // Удаление друга из списка друзей пользователя
  if (($key = array_search($friendId, $userFriends)) !== false) {
    unset($userFriends[$key]);
  } else {
    echo json_encode(array("success" => false, "message" => "Пользователь $friendEmail отсутствует в списке друзей пользователя $userEmail"));
    exit();
  }
  
  $updatedFriends = implode(', ', $userFriends);
  
  // Обновление списка друзей пользователя
  $updateQueryUser = $conn->query("UPDATE users SET friends = '$updatedFriends' WHERE id = '$userId'");
  
  if ($updateQueryUser === TRUE) {
    // Удаление пользователя userEmail из списка друзей пользователя friendEmail
    $friendFriendsQuery = $conn->query("SELECT friends FROM users WHERE id = '$friendId'");
    if ($friendFriendsQuery->num_rows > 0) {
      $friendFriendsRow = $friendFriendsQuery->fetch_assoc();
      $friendFriends = explode(', ', $friendFriendsRow['friends']);
      
      // Удаление пользователя userEmail из списка друзей пользователя friendEmail
      if (($key = array_search($userId, $friendFriends)) !== false) {
        unset($friendFriends[$key]);
      } else {
        echo json_encode(array("success" => false, "message" => "Пользователь $userEmail отсутствует в списке друзей пользователя $friendEmail"));
        exit();
      }
      
      $updatedFriendFriends = implode(', ', $friendFriends);
      
      // Обновление списка друзей пользователя friendEmail
      $updateQueryFriend = $conn->query("UPDATE users SET friends = '$updatedFriendFriends' WHERE id = '$friendId'");
      
      if ($updateQueryFriend === TRUE) {
        echo json_encode(array("success" => true, "message" => "Пользователь $friendEmail успешно удален из списка друзей пользователя $userEmail, и наоборот"));
      } else {
        echo json_encode(array("success" => false, "message" => "Ошибка при удалении пользователя $userEmail из списка друзей пользователя $friendEmail: " . $conn->error));
      }
    } else {
      echo json_encode(array("success" => false, "message" => "Пользователь $friendEmail не найден в базе данных"));
    }
  } else {
    echo json_encode(array("success" => false, "message" => "Ошибка при удалении пользователя $friendEmail из списка друзей пользователя $userEmail: " . $conn->error));
  }
} else {
  echo json_encode(array("success" => false, "message" => "Пользователь с указанным id не найден"));
}

$conn->close();
?>
