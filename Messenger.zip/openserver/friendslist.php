<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: *");

$conn = new mysqli("26.248.111.145", "root", "", "register");

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

$id = $_POST['id']; // Получаем почту пользователя

// Получаем строку с id друзей пользователя с указанной почтой
$friendIdsResult = $conn->query("SELECT `friends` FROM `users` WHERE `id` = '$id'");
$friendIdsRow = $friendIdsResult->fetch_assoc();
$friendIdsString = $friendIdsRow['friends']; // Строка с id друзей


// Разделяем строку на массив id пользователей
$friendIds = explode(', ', $friendIdsString);

$friendsCondition = implode(', ', array_fill(0, count($friendIds), '?'));

// Создаем строку параметров для связывания
$paramTypes = str_repeat('i', count($friendIds));
$paramValues = implode(', ', $friendIds);

// Создаем подготовленный запрос
$query = "SELECT * FROM `users` WHERE `id` IN ($friendsCondition)";
$stmt = $conn->prepare($query);

// Привязываем параметры
if ($stmt) {
    $stmt->bind_param($paramTypes, ...$friendIds);
    $stmt->execute();

    // Получаем результат запроса
    $result = $stmt->get_result();

    $friends = array();
    while ($row = $result->fetch_assoc()) {
        $friends[] = array("name" => $row['name'], "email" => $row['email'], "id" => $row['id']);
    }

    if (!empty($friends)) {
        echo json_encode(['status' => 'success', 'friends' => $friends]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No users found']);
    }

    // Закрываем запрос
    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Error in preparing statement']);
}

$conn->close();
?>
