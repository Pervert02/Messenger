<?php
// Подключение к базе данных
$servername = "26.248.111.145";
$username = "root";
$password = "";
$dbname = "register";

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Получение данных из POST запроса
$email = $_POST["email"];
$password = $_POST["password"];

//echo "Received username: $email, password: $password";
// Запрос к базе данных для проверки наличия пользователя
$sql = "SELECT * FROM users WHERE email='$email' AND pass='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "success".":". $row["id"].":".$row["name"]; // Возвращаем "success", если пользователь найден
} else {
    echo "user_not_found"; // Возвращаем "user_not_found", если пользователь не найден
}

$conn->close();
?>

