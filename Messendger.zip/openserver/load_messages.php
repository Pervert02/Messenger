<?php
// Подключение к базе данных
$servername = "26.248.111.145";
$username = "root"; // Ваше имя пользователя для подключения к базе данных
$password = ""; // Ваш пароль для подключения к базе данных
$dbname = "register"; // Имя вашей базы данных

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Ошибка подключения к базе данных: " . $conn->connect_error);
}

// Получение данных из POST-запроса
$email = $_POST['email'];
$friendEmail = $_POST['friendEmail'];

// Использование подготовленных выражений для предотвращения SQL инъекций
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Получаем id пользователя
    $row = $result->fetch_assoc();
    $userId = $row['id'];
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $friendEmail);
    $stmt->execute();
    $friendIdResult = $stmt->get_result();

    if ($friendIdResult->num_rows > 0) {
        $friendRow = $friendIdResult->fetch_assoc();
        $friendId = $friendRow['id'];

        // Получение всех сообщений между пользователями
        $chat_id = ($userId < $friendId) ? "$userId, $friendId" : "$friendId, $userId";
        // Получение всех сообщений между пользователями, где поле content не пустое
        // Получение всех сообщений между пользователями, где поле content не пустое
        $messagesQuery = "SELECT * FROM message WHERE chat_id = '$chat_id' AND content IS NOT NULL AND content != ''";
        $messagesResult = $conn->query($messagesQuery);

        if ($messagesResult->num_rows > 0) {
            // После цикла формируем ассоциативный массив с ключом 'messages'
            // После цикла формируем ассоциативный массив с ключом 'messages'
            $messages_array = array();
            while ($messageRow = $messagesResult->fetch_assoc()) {
                $messageData = array(
                    "userId" => $messageRow['user_id'],
                    "messageId" => $messageRow['message_id'],
                    "content" => $messageRow['content'],
                    "dateCreated" => $messageRow['date_create']
                );
                $messages_array[] = $messageData;
            }

            // Формируем ассоциативный массив с ключом 'messages', содержащий массив сообщений
            $response = array('messages' => $messages_array);
            echo json_encode($response);
        } else {
            echo "Нет сообщений между пользователями.";
        }
    } else {
        echo "Пользователь с таким email не найден";
    }
} else {
    echo "Пользователь с таким email не найден";
}

// Закрытие соединения с базой данных
$conn->close();
?>
